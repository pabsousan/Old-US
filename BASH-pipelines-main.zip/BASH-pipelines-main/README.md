# BASH-pipelines
Creating a pipeline for RNA-seq and ChIP-seq
